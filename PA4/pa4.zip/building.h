#ifndef __BUILDING__
#define __BUILDING__
#include<stdio.h>
#include"hbt.h"

Tnode *Insertion(Tnode *head, int keyy, int *error);

Tnode *Deletion(Tnode *head, int keyy, int *error);

#endif